package request.form.post;

public interface Entity {
public void next();

}
