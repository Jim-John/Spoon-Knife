package request.form.post;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//web xml dosyasinda bulunan tanimlamalari iptal edip Annotation'lari kullanabiliriz.
//@WebServlet("/requestPostFormURL")
public class RequestPostForm1 extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		//dataBinding(req);
		RequestDispatcher dispatcher = req.getRequestDispatcher("login2.jsp");
		dispatcher.forward(req, resp);

	}
   /**
    * 
    * @param req
    */
	private void dataBinding(HttpServletRequest req) {
		String name = req.getParameter("user_name");
		String email = req.getParameter("user_email");
		String password = req.getParameter("user_password");
		System.out.println(name);
		System.out.println(email);
		System.out.println(password);
		Person person = new Person(name, email, password);
		req.setAttribute("myPerson", person);
		
	}
	

}
